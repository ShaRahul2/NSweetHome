package com.upgrade.bookingservice.model.exception;

public abstract class ApiSubError {
}
