package com.upgrade.paymentservice.exception;

public abstract class ApiSubError {
}
